# LGM-VIP-Covid-Tracker

Covid Statistics Tracking Android Application.It Shows Data All over India Stata-wise as well as District Data.
It fetches Data From Provided Api.
